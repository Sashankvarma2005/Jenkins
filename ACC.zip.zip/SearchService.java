package com.mockcompany.webapp.services;

import com.mockcompany.webapp.data.ProductItemRepository;
import com.mockcompany.webapp.model.ProductItem;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class SearchService {

    private final ProductItemRepository productItemRepository;

    public SearchService(ProductItemRepository productItemRepository) {
        this.productItemRepository = productItemRepository;
    }

    public Collection<ProductItem> searchProducts(String query) {
        Iterable<ProductItem> allItems = this.productItemRepository.findAll();
        List<ProductItem> itemList = new ArrayList<>();
        boolean exactMatch = query.startsWith("\"") && query.endsWith("\"");

        if (exactMatch) {
            query = query.substring(1, query.length() - 1); // Remove quotes
        } else {
            query = query.toLowerCase(); // Case-insensitive
        }

        for (ProductItem item : allItems) {
            boolean nameMatches;
            boolean descMatches;
            if (exactMatch) {
                nameMatches = query.equals(item.getName());
                descMatches = query.equals(item.getDescription());
            } else {
                nameMatches = item.getName().toLowerCase().contains(query);
                descMatches = item.getDescription().toLowerCase().contains(query);
            }

            if (nameMatches || descMatches) {
                itemList.add(item);
            }
        }
        return itemList;
    }
}
